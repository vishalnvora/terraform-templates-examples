# Type Hints

All of these scripts are used to test the type hinting
distributed with the `elasticsearch` package.
These scripts simulate normal usage of the client and are run
through `mypy --strict` as a part of continuous integration.
