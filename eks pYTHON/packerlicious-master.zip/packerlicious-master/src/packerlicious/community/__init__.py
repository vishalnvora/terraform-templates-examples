"""
packer plugins that are not distributed with packer core.
"""
