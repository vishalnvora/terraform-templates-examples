### packerlicious version
<!-- what version of packerlicious are you using? -->



### Expected behavior
<!-- what did you expect to happen? -->



### Actual behavior
<!-- what actually happened instead? -->



### Steps to reproduce

<!-- what steps can someone take to reproduce the actual behavior? -->
