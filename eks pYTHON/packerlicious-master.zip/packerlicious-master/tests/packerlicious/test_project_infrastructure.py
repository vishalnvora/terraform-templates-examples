def test_travis_with_coveralls():
    assert True
