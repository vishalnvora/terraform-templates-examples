# Contributing

By participating in packerlicious project, you agree to our [code of conduct]

[code of conduct]: https://github.com/mayn/packerlicious/blob/master/CODE_OF_CONDUCT.md


### Pull-Requests
1. Create an issue that clearly outlines the problem/ feature you are trying to solve.
1. Squash your commits when appropriate.
