# Tests

ansible-playbook kibana_functional_tests.yml 
