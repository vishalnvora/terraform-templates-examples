'''
Created on Oct 3, 2017

@author: Liza Dayoub
'''


class IndexPatternDoesNotExist(Exception):
    """Raise when index pattern does not exist"""
    pass
